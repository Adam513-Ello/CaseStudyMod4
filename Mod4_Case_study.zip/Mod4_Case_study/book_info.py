from .book import book
newbook = book.objects.create(
    id = "1234567891011",
    book_name = "TestBook",
    author = "Adam",
    publisher = "Pearson"
)

books = book.objects.all()
print(books)



