from django.db import models
class book(models.Model):
    id = models.CharField(max_length = 13)
    book_name = models.CharField(max_length = 100)
    author = models.CharField(max_length = 25)
    publisher = models.CharField(max_length = 25)
    
    def __str__(self):
        return f"{self.book_name} {self.publisher}"
    
    
    
#id
#book_name
#author
#publisher