from django.contrib import admin
from .book import book
admin.site.register(book)